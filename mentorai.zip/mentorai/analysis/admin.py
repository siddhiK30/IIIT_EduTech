from django.contrib import admin
from .models import StudentProgress

admin.site.register(StudentProgress)
